console.log("entro a validar con js");

//agregar el lisener para que al hacer click en el boton se dispare una funcion

function validacion() {
   var N=  document.getElementById("nombre").value;
   
   console.log (N);
}
